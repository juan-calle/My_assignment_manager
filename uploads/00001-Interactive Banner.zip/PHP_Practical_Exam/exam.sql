# ************************************************************
# Sequel Pro SQL dump
# Version 4004
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.29)
# Database: exam
# Generation Time: 2013-04-04 16:26:16 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table olympics
# ------------------------------------------------------------

DROP TABLE IF EXISTS `olympics`;

CREATE TABLE `olympics` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sport` varchar(30) DEFAULT NULL,
  `info` varchar(1000) DEFAULT NULL,
  `goldTally` int(3) DEFAULT NULL,
  `silverTally` int(3) DEFAULT NULL,
  `bronzeTally` int(3) DEFAULT NULL,
  `image` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `olympics` WRITE;
/*!40000 ALTER TABLE `olympics` DISABLE KEYS */;

INSERT INTO `olympics` (`id`, `sport`, `info`, `goldTally`, `silverTally`, `bronzeTally`, `image`)
VALUES
	(1,'Archery','<p>Archery is truly a historic sport, a contest of mind and body control, as well as precision, and has roots dating back to its use as a weapon of hunting and war in ancient times.</p><p>Olympic Archers shoot at a target measuring just 122 from a distance of 70 metres. To achieve maximum marks they must hit the gold centre ring measuring just 12.2cm.</p>',2,2,5,'01.jpg'),
	(2,'Athletics','<p>The Olympic competition schedule consists of 47 events; 24 for men and 23 for women.</p><p>Athletics is an exclusive collection of sporting events that involve competitive running, jumping, throwing, and walking. The most common types of athletics competitions are track and field, road running, cross country running, and race walking.</p>',49,78,61,'02.jpg'),
	(3,'Badminton','<p>Badminton is the world?s fastest racquet sport where players compete to hit a shuttlecock back and forth over a high net. The record for the fastest smash currently stands at an amazing 421 kph.</p><p>As a result, the players have to have lightning-fast reactions and incredible agility and stamina, often covering up to six kilometres in a match as they dart back and forth across the indoor courts.</p>',0,1,1,'03.jpg'),
	(4,'Basketball','<p>Basketball is played by two teams, made up of five players and seven substitutes. The aim of the game for each team is to get the ball into the elevated baskets at either end of the court more times than the opposition, while preventing the opposition from scoring at the same time.</p><p>A game is made up of four periods, each lasting 10 minutes of actual playing time. If the scores are tied at the end of the game, extra five-minute overtime periods are played until a winner is declared.</p>',0,0,0,'04.jpg'),
	(5,'Beach Volleyball','<p>Beach volleyball is the outdoor equivalent of volleyball and ? despite its glamorous, sun-kissed image ? is every bit as grueling as its indoor counterpart.</p><p>Although beach volleyball is not always played on an actual beach, the deep sand base used for the court provides little grip, but is a soft surface for landings. This means that games can get incredibly physical as players dive to catch shots without the risk of serious injury that a hard floor would cause.</p>',0,0,0,'05.jpg'),
	(6,'Boxing','<p>Boxing is one of the most illustrious and historic sports in the Olympic Games. Men have sparred in competition since 5000BC in the Middle East, while boxing was one of the key events in the original Olympic Games in ancient Greece.</p><p>Although boxing is a highly aggressive sport, it also places great emphasis on technique, concentration and physical stamina. The best boxers of ancient Greece ? such as Melagomas ? were actually more famous for their ?atravmatistos? (or uninjured) boxing style.</p>',14,11,23,'06.jpg'),
	(7,'Cycling Road','<p>Road racing is the form of competitive cycling most analogous to that done by the general public, with riders competing against each other on conventional roads to complete the course in the fastest time possible.</p><p>It has been part of the modern Olympics since the inaugural Summer Games in Athens, Greece in 1896. That year, competitors rode for two laps of the marathon route from Athens to Marathon and back - a distance of 87 kilometres.</p>',1,7,4,'07.jpg'),
	(8,'Cycling Track','<p>In comparison to road racing and mountain biking, track cycling is an incredibly specialised indoor event, with a number of disciplines that place as much emphasis on strategy and subtle technique as on physical fitness, power and stamina.</p><p>Races take place on an indoor velodrome - a 250m wooden oval, with straights banked at 12 degrees and the corners banked at a steep 42 degree angle. The bikes and equipment used by the riders are also highly specialised, and bear little semblance to road-going machinery.</p>',15,17,17,'08.jpg'),
	(9,'Diving','<p>Diving is an incredibly specialised aquatic discipline in which athletes leap from platforms or springboards elevated to a height of three metres and 10 metres above the pool. It requires physical poise and great courage.</p><p>During their fall, they do a number of spins, flips and twists before hitting the water at speeds of up to 55kph.</p>',0,2,4,'09.jpg'),
	(10,'Equastrian','<p>The Equestrian disciplines are unique among Olympic sports, in the sense that men and women compete on the same terms and horse and rider are both declared Olympic medal winners.</p><p>Eventing is a combination of Dressage, Jumping and Cross-Country tests which are carried out over 4 consecutive days. </p>',5,6,7,'10.jpg'),
	(11,'Fencing','<p>Fencing is a combat sport using three blade weapons: foil, sabre and epee.  It is one of only four sports that have featured at every modern Olympic Games.  Fencing calls for a combination of excellent footwork and fast and accurate bladework. </p>',1,8,0,'11.jpg'),
	(12,'Football','<p>Modern football has evolved from a game played in streets and schools in the mid 1800s to the most widely played game on earth played in almost every town and village in the world, from youngsters kicking a ball about in the streets and local league teams playing for local honour to vast stadiums where the multi million pound clubs draw up to 100,000 fans each week.</p>',3,0,0,'12.jpg'),
	(13,'Gymnastics','<p>Gymnastics is one of the most popular disciplines of the Olympic Games and at the same time one of the most demanding, since it combines strength, skill and flexibility.</p><p>Men participate in six apparatus: Floor Exercises, Pommel Horse, Rings, Vault, Parallel Bars and Horizontal Bar. Women participate in four apparatus: Vault, Uneven Bars, Balance Beam and Floor Exercises</p>',0,1,3,'13.jpg'),
	(14,'Handball','<p>Handball is played in an indoor court between two teams, of seven players each. The players? objective is, by only using their hands, to throw the ball into the goal of the opposing team, thereby scoring a \"goal\". The team with the most goals at the end of the match wins.</p>',0,0,0,'14.jpg'),
	(15,'Hockey','<p>A game consists of two 35-minute periods, with a 10 minute interval for half-time.</p><p>There are 12 teams of 16 players which are placed into two pools of six for the preliminary rounds. Each team plays every other team in that pool. The top two teams in each pool progress to the semifinals. The remaining teams play for classification 5-12. Winners of the semifinals play for the gold medal, and losers of the semifinal play for the bronze.</p>',3,2,5,'15.jpg'),
	(16,'Judo','<p>Although Judo is a martial art, its practice and methods are based around gentleness. Giving way to the strength of the opponent, adapting to and using it to your advantage will achieve victory over the opponent.</p>',0,7,9,'16.jpg'),
	(17,'Modern Pentathlon','<p>The combination of five completely different sports constitutes Modern Pentathlon, the most demanding sport of the Olympic Games. Pentathletes compete in the course of one day, in the following five disciplines: Fencing, Swimming, Riding, and then combined Shooting and Cross-country running. Modern Pentathlon men and women athletes need to have strength, endurance, quick reflexes and concentration, in order to meet the high demands of the sport.</p>',2,1,3,'17.jpg'),
	(18,'Rowing','<p>A sport involving 14 different classes of boat and between one and eight rowers. Rowing requires athletes with incredible upper body strength and a commitment to the sport from an early age in order to develop the correct physical shape and muscle definition.</p><p>Rowing has given us the man who many regard as the Athlete of the Century in Sir Steve Redgrave, winner of six World Championship and five Olympic Gold Medals. </p>',24,20,10,'18.jpg'),
	(19,'Sailing','<p>Sailing competition is run in different classes, or types of boats. In any race, only boats of the same class compete against each other.</p><p>The 10 classes of boats used in the 2012 Olympic Games are single-handed, double-handed or triple-handed disciplines. The International Sailing Federation selects the classes for each Olympic Games and the classes do, and have, changed over the years.</p>',25,14,11,'19.jpg'),
	(20,'Shooting','<p>A sport that demands exceptional concentration and a strong mental approach.</p><p>Olympic shooting events are split into three categories: Shotgun, Pistol and Rifle. </p>',12,15,16,'20.jpg'),
	(21,'Swimming','<p>Swimming is a hugely physical and demanding sport, with athletes competing over distances from 50m to 1,500m in the pool. Swimmers need huge strength and stamina to power themselves through the water, as well as perfectly honed technique. </p>',15,22,28,'21.jpg'),
	(22,'Synchronised swimming','<p>Synchronised swimming is often described as ?water ballet?, because of the dance-like movements swimmers make to music, and its theatrical character. Even though it looks like one of the easier Olympic disciplines, synchronised swimming actually calls for strength, endurance, flexibility, grace, artistry, and special endurance breathing techniques.</p>',0,0,0,'22.jpg'),
	(23,'Table Tennis','<p>There are four table tennis competitions: men?s and women\'s singles, and men\'s and women?s team event at the Olympics.</p><p>All events follow a knockout (single elimination) format. For both singles competitions each match consists of the best four out seven games to at least 11 points, where the winner must win by at least two points.</p>',0,0,0,'23.jpg'),
	(24,'Taekwondo','<p>A Korean form of martial art, which has been the dominant form of martial art in that country since 1955</p><p>Each of the eight weight categories involves a single elimination tournament with a double repechage for the bronze medal contest. This means that, for an athlete to make it to the gold medal match, he or she must have progressed through the preliminary rounds undefeated; whereas the bronze medal match will be between two players who have each lost one contest.</p>',0,0,1,'24.jpg'),
	(25,'Tennis','<p>A sport that has been around since the Middle Ages, Tennis is a raquet and ball game that can be played either in singles or doubles over five sets (for men) or three sets (for women).</p><p>Tennis has evolved into a truly high profile international sport with the top players some of the highest profile sportsman and women in the world earning millions of pound in prize money. In the Olympics however, they play only for medals, like every other athlete. </p>',15,13,12,'25.jpg'),
	(26,'Triathlon','<p>Claimed by some to be the ultimate test of human endurance, Triathlon pushes its competitors to the limits in three different sports: Swimming, cycling and running. Each sport requires the the competitor to be in peak physical condition and with three such individual sports it calls on the athlete to commit to a training schedule that is second to none.</p>',0,0,0,'26.jpg'),
	(27,'Volleyball','<p>Traditional six-a-side indoor volleyball is referred to at the Olympic Games as volleyball. So the Olympic sport of volleyball has two disciplines - beach volleyball and volleyball. Both disciplines follow the same basic skills, and the flow of play follows similar lines: one team serves, the other tries to win the rally - or \'side-out\' - with a pattern of dig, set, spike within the requisite three touches.</p>',0,0,0,'27.jpg'),
	(28,'Water Polo','<p>Water polo is a highly physical team sport in which the players of each squad try to score as many goals against the opposition as they can, while preventing their rivals from scoring goals at the same time. It requires fast reactions and finesse as well as great endurance, as players can swim up to 1500m in a match.</p>',4,0,0,'28.jpg'),
	(29,'Weightlifting','<p>A sport about technique every bit as it is about pure strength. Weightlifting has been around as long as competition itself.</p><p>Weightlifting consists of two movements executed in a standard order: first the snatch and then the clean jerk. There are both men and women Weightlifting events. Each athlete has the right to three attempts for each movement. The athlete?s best performances in both movements are put together to determine the final placement.</p>',1,3,3,'29.jpg'),
	(30,'Wrestling','<p>A sport as old as mankind itself. Since the dawn of time men have been pitted against each other in physical hand to hand combat, making this almost certainly the most ancient of Olympic sports.</p><p>It?s a simple concept. Two men or women fight until one of them is subdued. But the techniques of wresting have become sophisticated and winning is about having the ability to use not only your weight and skill but also the weight of your opponent.</p>',3,4,10,'30.jpg');

/*!40000 ALTER TABLE `olympics` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
