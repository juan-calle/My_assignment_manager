<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "exam";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
    mysqli_select_db("users",$conn) or die("Cannot Find serer");
}
?> 

<!DOCTYPE html>
<html>
<head>
<title>London2012 Olympics</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div id="container">
 <h1>London 2012 Olympics</h1>
 <img class="pull-right" src="images/logo.png" width='100' height '100'>
 <table class="table table-bordered table-condensed">
 <thead>
 <th>Sport</th>
 <th>Description</th>
 <th>Image</th>
 <th>Gold Medals</th>
 <th>Silver Medals</th>
 <th>Bronze Medals</th>
 </thead>

<?php 
$query = "SELECT * FROM olympics ORDER BY sport ";
$data = mysqli_query($conn,$query);
while ($row = $data->fetch_assoc()) {
$sportTitle = $row["sport"];
$sportDesc = $row["info"];
$sportImg = $row["image"]; 
$sportGold = $row["goldTally"];
$sportSilver = $row["silverTally"];
$SportBronze = $row["bronzeTally"];
echo " 
 <tbody>
 <tr>
 	<td>".$sportTitle."</td>
 	<td>".$sportDesc."</td>
 	<td><img src='/PHP_Practical_Exam/images/".$sportImg."' width='180' height '180'></td>
 	<td>".$sportGold."</td>
 	<td>".$sportSilver."</td>
 	<td>".$SportBronze."</td>
 </tr>
 </tbody>";}
?>
</table>
</div>
</body>
</html>
